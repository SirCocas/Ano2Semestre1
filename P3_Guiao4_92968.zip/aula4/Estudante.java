package aula4;

import aula3.Data;

public class Estudante extends Pessoa {
	private int nMec;
	static int number = 100;
	private Data DataInsc = new Data(4, 10, 2019);

	public Estudante(String nome, int bi, Data data) {
		super(nome, bi, data);
		nMec = number;
		number++;
		// TODO Auto-generated constructor stub
	}
	public Estudante(String nome, int bi, Data data, int nMec) {
		super(nome, bi, data);
		this.nMec=nMec;
	}

	public int nMec() {
		return nMec;
	}

	@Override
	public String toString() {
		return (super.toString() + "|| NMec: " + nMec + "||Data de inscricao: " + DataInsc);
	}
	
	public String type() {
		return "Estudante";
	}

}
