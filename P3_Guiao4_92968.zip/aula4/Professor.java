package aula4;

import aula3.Data;

public class Professor extends Pessoa {

	public Professor(String nome, int bi, Data data) {
		super(nome, bi, data);
	}
	
	@Override public String toString() {
		return super.toString();
	}

}
