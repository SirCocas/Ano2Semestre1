package aula4;

public class Disciplina {
	private String nome="";
	private String area="";
	private int ECT = 0;
	private Professor responsavel;
	private Estudante [] alunos = new Estudante [0];
	
	public Disciplina(String string, String string2, int i, Professor pf1) {
		nome=string;
		area=string2;
		ECT=i;
		responsavel=pf1;
	}
	
	public String nome() {
		return nome;
	}
	public String area() {
		return area;
	}
	public int ECT() {
		return ECT;
	}
	public Professor responsavel() {
		return responsavel;
	}

	public boolean addAluno(Estudante est) {
		boolean state = !(alunoInscrito(est.nMec()));   
		if(state) {
			alunos=grow(alunos);
			alunos[alunos.length-1]=est;
			return true;
		}
		return false;
	}
	
	public boolean delAluno(int nMec) {
		boolean state = (alunoInscrito(nMec));
		int contador=0;
		if(state) {
			Estudante [] temp = new Estudante[numAlunos()-1];
			for(int i=0; i<alunos.length; i++) {
				if(alunos[i].nMec()!= nMec) {
					temp[contador]=alunos[i];
					contador++;
				}
			}
			this.alunos=temp;
			return true;
		}
		return false;
	}
	
	public boolean alunoInscrito(int nMec) {
		for(int i=0; i<alunos.length; i++) {
			if (alunos[i].nMec() == nMec) {
				return true;
			}
		}
		return false;
		//returns true if student is a part of class
	}
	
	public int numAlunos() {
		return alunos.length;
	}
	
	
	public Estudante[] getAlunos() {
		return alunos;
	}
	
	public Estudante[] getAlunos(String tipo) {
		Estudante [] temp = new Estudante[0];
		int contador=0;
		for(int i=0; i<alunos.length; i++) {
			if(alunos[i].type().equals(tipo)) {
				temp=grow(temp);	
				temp[contador]=alunos[i];
				contador++;
			}
		}
		return temp;
	}
	
	public Estudante[] grow(Estudante [] arr) {
		if(arr.length==0) {
			Estudante [] temp = new Estudante[1];
			return temp;
		}
		Estudante[] temp = new Estudante[arr.length +1];
		System.arraycopy(arr, 0, temp, 0, arr.length);
		return temp;
	}

	public boolean addAluno(Bolseiro bls3) {
		Estudante temp = new Bolseiro(bls3);
		return addAluno(temp);
	}
	
	@Override public String toString() {
		return "Nome: "+nome+"|| Area: "+area+"|| ECTs: "+ECT+"|| Responsavel: "+responsavel;
	}
		


}
