package aula4;

public class Ponto {
	private int x = 0;
	private int y = 0;

	public Ponto(int x, int y) {
		this.x = x;
		this.y = y;
	}

	public boolean equals(Object rhs) {
		if (rhs == null)
			return false;
		if (getClass() != rhs.getClass())
			return false;
		if (rhs == this)
			return true;
		return ((x == ((Ponto) rhs).x) && (y == ((Ponto) rhs).y));
	}

	@Override
	public String toString() {
		return ("X: " + x + "|| Y: " + y);
	}

}
