package aula4;

public class ColecaoFiguras {
	private double maxArea=0;
	private Figura [] dados = new Figura [0];
	private double areaTotal=0;
	
	public ColecaoFiguras(double d) {
		maxArea= d;
	}
	
	public boolean addFigura(Figura f) {
		boolean state = ! exists(f);   
		if(state && (areaTotal+ f.area() <=maxArea)) {
			dados=grow(dados);
			dados[dados.length-1]=f;
			areaTotal+=f.area();
			return true;
		}
		return false;
	}
	
	private Figura[] grow(Figura[] arr) {
		if(arr.length==0) {
			Figura [] temp = new Figura[1];
			return temp;
		}
		Figura[] temp = new Figura[arr.length +1];
		System.arraycopy(arr, 0, temp, 0, arr.length);
		return temp;
	}

	public boolean exists(Figura f) {
		for(int i=0; i<dados.length; i++) {
			if(f.equals(dados[i]))
				return true;
		}
		return false;
	}
	
	public boolean delFigura(Figura f) {
		boolean state = (exists(f));
		int contador=0;
		if(state) {
			areaTotal-=f.area();
			Figura [] temp = new Figura[dados.length-1];
			for(int i=0; i<dados.length; i++) {
				if(! dados[i].equals(f)) {
					temp[contador]=dados[i];
					contador++;
				}
			}
			this.dados=temp;
			return true;
		}
		return false;
		
	}
	public double areaTotal() {
		return areaTotal;
		
	}
	@Override public String toString() {
		String a="";
		for(int i=0; i<dados.length; i++) {
			a+=dados[i].toString();
		}
		return a;
	}
	public Figura[] getFiguras() {
		return dados;
		
	}
	public Ponto[] getCentros() {
		Ponto[] centros = new Ponto[dados.length];
		for(int i=0; i<centros.length; i++) {
			centros[i]=dados[i].centro();
		}
		return centros;
		
	}

}
