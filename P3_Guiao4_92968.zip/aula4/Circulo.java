package aula4;


public class Circulo extends Figura {
	int raio = 0;

	public Circulo(int i) {
		super();
		if (i > 0)
			raio = i;
	}

	public Circulo(int i, int j, int k) {
		super(i, j);
		if (k > 0)
			raio = k;
	}

	public Circulo(Circulo c1) {
		super(c1.centro);
		this.raio = c1.raio();
	}

	public int raio() {
		return raio;
	}

	@Override public boolean equals(Object rhs) {
		return super.equals(rhs) && raio == ((Circulo) rhs).raio;
	}

	public double area() {
		return raio * raio * Math.PI;
	}

	public double perimetro() {
		return 2 * raio * Math.PI;
	}

	@Override
	public String toString() {
		return ("CIRCULO: "+super.toString() + "|| Raio: " + raio);
	}

}
