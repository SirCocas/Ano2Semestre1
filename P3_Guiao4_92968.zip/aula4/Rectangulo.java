package aula4;


public class Rectangulo extends Figura {
	private int comp = 0;
	private int larg = 0;

	public Rectangulo(int i, int j) {
		super();
		if (i > 0)
			comp = i;
		if (j > 0)
			larg = j;
	}

	public Rectangulo(int i, int j, int k, int l) {
		super(i, j);
		if (k > 0)
			comp = k;
		if (l > 0)
			larg = l;
	}

	public Rectangulo(Rectangulo r1) {
		super(r1.centro);
		comp = r1.comp;
		larg = r1.larg;
	}

	@Override public boolean equals(Object rhs) {
		// Não é necessário testar a classe. Feito em base
		return (super.equals(rhs)) && (comp == ((Rectangulo) rhs).comp) && (larg == ((Rectangulo) rhs).larg);
	}

	public double area() {
		return comp * larg;
	}

	public double perimetro() {
		return (comp * 2) + (larg * 2);
	}

	@Override
	public String toString() {
		return ("RETANGULO: "+super.toString() + "|| Comprimento: " + comp + "|| Largura: " + larg);
	}

}


