package aula4;

import aula3.Data;

public class Bolseiro extends Estudante {
	private int bolsa = 0;

	public Bolseiro(String nome, int bi, Data data) {
		super(nome, bi, data);
		// TODO Auto-generated constructor stub
	}
	
	public Bolseiro(Bolseiro bls) {
		super(bls.nome(), bls.BI(), bls.DataNasc(), bls.nMec());
		setBolsa(bls.bolsa);
	}

	public void setBolsa(int bolsa) {
		this.bolsa = bolsa;
	}

	public int bolsa() {
		return bolsa;
	}

	@Override
	public String toString() {
		return (super.toString() + "|| Bolsa: " + bolsa);
	}
	
	public String type() {
		return "Bolseiro";
	}

}
