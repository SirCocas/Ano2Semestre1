package aula4;

public class Figura {
	protected Ponto centro = new Ponto(0, 0);

	public Figura(Ponto ponto) {
		this.centro = ponto;
	}

	public Figura(int x, int y) {
		centro = new Ponto(x, y);
	}

	public Figura() {
		centro = new Ponto(0, 0); // um pouco redundante mas é para ter a certeza que temos um centro
	}

	public boolean equals(Figura c1) {
		if ( c1 == null ) return false;
		if ( getClass() != c1.getClass() ) return false;
		if (c1 == this) return true;
		return centro.equals(c1.centro);
			
}	

	@Override
	public String toString() {
		return centro.toString();
	}

	public double area() {
		return 0;
	}

	public Ponto centro() {
		return centro;
	}


}
