package aula5;
import java.io.*;
import java.util.Scanner;


public class readFile{
	public static Contacto[] readFile(String filename) throws IOException {
		File ficheiro = new File(filename);
		Scanner in = new Scanner(ficheiro);
		String nome= in.nextLine();
		if(nome.equals("Nokia"))
			return readNokia(in);
		if(nome.equals("vCard"))
			return readvCard(in);
		if(nome.equals("CSV"))
			return readCSV(in);
		Contacto[] agenda = new Contacto[1];
		agenda[0]= new Contacto("Sofia", "2345", 11,1,2000);
		return agenda;
	}

	public static Contacto[] readCSV(Scanner in) {
		Contacto[] agenda = new Contacto[0];
		int n=0;
		while(in.hasNextLine()) {
			String line = in.nextLine();
			String [] dados=line.trim().split("\\t");
			agenda=grow(agenda);
			agenda[n]= new Contacto(dados[0], dados[1], dados[2]);
			n++;
		}
		return agenda;
	}

	public static Contacto[] readvCard(Scanner in) {
		Contacto[] agenda = new Contacto[0];
		int n=0;
		while(in.hasNextLine()) {
			String line = in.nextLine();
			String [] dados=line.split("#");
			agenda=grow(agenda);
			agenda[n]= new Contacto(dados[1], dados[2], dados[3]);
			n++;
		}
		return agenda;
	}

	public static Contacto[] readNokia(Scanner in) {
		Contacto[] agenda = new Contacto[0];
		int n=0;
		while(in.hasNextLine()) {
			String name = in.nextLine();
			if(! name.isEmpty()) {
				agenda=grow(agenda);
				String number = in.nextLine();
				String data= in.nextLine();
				agenda[n]= new Contacto(name, number, data);
				n++;
			}
		}
		return agenda;
	}
	private static Contacto[] grow(Contacto[] arr) {
		if(arr.length==0) {
			Contacto [] temp = new Contacto[1];
			return temp;
		}
		Contacto[] temp = new Contacto[arr.length +1];
		System.arraycopy(arr, 0, temp, 0, arr.length);
		return temp;
	}
}
