package aula5;

public class MotoPolicia extends Moto implements Policia{
	private static int IDall = 0;
	private String ID;
	private Tipo type;
	public MotoPolicia(int ano, String matricula, Cor cor, int cilindrada, double vel, Tipo type,int potencia, double consumo, Combustivel combustivel) {
		super(ano, matricula, cor, cilindrada, vel, potencia, consumo, combustivel);
		this.type=type;
		ID="M"+IDall;
		IDall++;
	}
	@Override
	public Tipo getTipo() {
		return type;
	}
	@Override
	public String getID() {
		return ID;
	}
	
	@Override public String toString() {
		return super.toString()+"ID: "+ID+" Tipo: "+type;
	}

}
