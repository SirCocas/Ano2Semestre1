package aula5;

enum Combustivel {
GASOLINA, GASOLEO;}

public interface Motorizado {
	public String getPotencia();
	public double getConsumo();
	public Combustivel getComustivel();

}
