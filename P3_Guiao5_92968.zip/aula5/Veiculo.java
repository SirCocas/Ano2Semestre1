package aula5;

public abstract class Veiculo implements Comparable<Veiculo> {
	private int ano;
	private String matricula;
	private Cor cor;
	private int nRodas;
	private int cilindrada;
	private double vel;
	
	public Veiculo(int ano, String matricula, Cor cor, int nRodas, int cilindrada, double vel){
		this.ano=ano;
		this.matricula=matricula;
		this.cor=cor;
		this.nRodas=nRodas;
		this.cilindrada=cilindrada;
		this.vel=vel;
	}
	public int ano() {
		return ano;
	}
	
	public String matricula() {
		return matricula;
	}
	
	public Cor cor() {
		return cor;
	}
	
	public int nRodas() {
		return nRodas;
	}
	
	public int cilindrada() {
		return cilindrada;
	}
	
	public double vel() {
		return vel;
	}
	
	public int compareTo(Veiculo veiculo) {
		if(veiculo.ano()<ano)
			return 1;
		if(veiculo.ano()>ano)
			return -1;
		return 0;
	}
	
	public String toString() {
		return "Ano: "+ano+" Matricula: "+matricula+" Cor: "+cor+" Numero de rodas: "+nRodas+" Cilindrada: "+cilindrada+" Velocidade maxima: "+vel;
	}
}
