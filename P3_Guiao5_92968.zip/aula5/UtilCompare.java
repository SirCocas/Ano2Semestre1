package aula5;

public abstract class UtilCompare implements Comparable<Object> {

	public static Object findMax(Comparable[] list) {
		Object max=list[0];
		for(int i=1; i<list.length; i++)
			if (((Comparable) max).compareTo(list[i]) < 0)
				max=list[i];
		return max;
	}

	public static Comparable[] sortArray(Comparable[] list) {
		for(int i=0; i<list.length; i++) {
			for(int c=i; c<list.length; c++) {
				if(list[i].compareTo(list[c]) > 0) {
					Object a = list[c];
					list[c]=list[i];
					list[i]=(Comparable) a;
				}
			}
		}
		return list;
	}
	
}
