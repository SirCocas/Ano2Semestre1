package aula5;

public class BicicletaPolicia extends Bicicleta implements Policia {
	private static int IDall = 0;
	private String ID;
	private Tipo type;
	public BicicletaPolicia(int ano, String matricula, Cor cor, double vel, Tipo type) {
		super(ano, matricula, cor, vel);
		ID = "B"+IDall;
		IDall++;
		this.type=type;
	}
	@Override
	public Tipo getTipo() {
		return type;
	}
	@Override
	public String getID() {
		return ID;
	}
	
	@Override public String toString(){
		return super.toString()+" ID: "+ID +" Tipo: "+type;
	}
}
