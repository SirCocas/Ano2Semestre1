package aula5;

public class Bicicleta extends Veiculo {

	public Bicicleta(int ano, String matricula, Cor cor, double vel) {
		super(ano, matricula, cor, 2, 0, vel);
	}

}
