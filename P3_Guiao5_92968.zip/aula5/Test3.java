package aula5;
import java.io.IOException;
import java.util.*;

public class Test3 {

	public static void main(String[] args) throws IOException {
		//teste de leitura de Nokia
		System.out.println("Dados do ficheiro do tipo NOKIA");
		Scanner sc = new Scanner(System.in);
		String nome="contactsNokia.txt";
		Contacto [] dadosNokia = readFile.readFile(System.getProperty("user.dir")+"/"+nome);
		for(int i=0; i<dadosNokia.length; i++)
			System.out.println(dadosNokia[i]);
		
		//teste de leitura de CSV 
		System.out.println("");
		System.out.println("Dados do ficheiro do tipo CSV:");
		nome = "contactsCSV.txt";
		Contacto [] dadosCSV = readFile.readFile(System.getProperty("user.dir")+"/"+nome);
		for(int i=0; i<dadosCSV.length; i++)
			System.out.println(dadosCSV[i]);
		System.out.println("");
		
		//teste de leitura de VCard
		System.out.println("Dados do ficheiro do tipo VCard:");
		nome = "contactsVCard.txt";
		Contacto [] dadosVCard = readFile.readFile(System.getProperty("user.dir")+"/"+nome);
		for(int i=0; i<dadosVCard.length; i++)
			System.out.println(dadosVCard[i]);
		
		//Escrita de um ficheiro de cada tipo, para poder comparar com o ficheiro inicial
		writeFile.writeNOKIA("nokiaOut.txt", dadosNokia);
		writeFile.writeCSV("CSVout.txt", dadosCSV);
		writeFile.writeVCard("VCardout.txt", dadosVCard);

		
		
	}

}
