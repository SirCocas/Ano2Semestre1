package aula5;

public class Moto extends Veiculo implements Motorizado {
	private String potencia;
	private double consumo;
	private Combustivel comb;
	public Moto(int ano, String matricula, Cor cor, int cilindrada, double vel, int potencia, double consumo, Combustivel combustivel) {
		super(ano, matricula, cor, 2, cilindrada, vel);
		this.potencia=""+ potencia +"CC";
		this.consumo=consumo;
		comb=combustivel;
	}

	@Override
	public String getPotencia() {
		return potencia;
	}

	@Override
	public double getConsumo() {
		return consumo;
	}

	@Override
	public Combustivel getComustivel() {
		return comb;
	}
	
	@Override public String toString() {
		return super.toString()+" Potencia: "+potencia+" Consumo: "+consumo+" Combustivel: "+comb;
	}

}
