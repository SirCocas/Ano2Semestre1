package aula5;


public class Quadrado extends Figura{
	private int side;

	public Quadrado(int i) {
		super();
		if (i > 0)
			side = i;
		this.area=area();
	}

	public Quadrado(int i, int j, int k) {
		super(i, j);
		if (k > 0)
			side = k;
		this.area=area();
	}

	public Quadrado(Quadrado q2) {
		super(q2.centro);
		this.side = q2.side;
		this.area=area();
	}

	public double area() {
		return side * side;
	}

	public double perimetro() {
		return side * 4;
	}

	@Override  public boolean equals(Object rhs) {
		// Não é necessário testar a classe. Feito em base
		return super.equals(rhs) && side == ((Quadrado) rhs).side;
	}

	@Override
	public String toString() {
		return ("QUADRADO: "+super.toString() + "|| Lado: " + side);
	}

}
