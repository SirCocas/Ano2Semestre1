package aula5;

public enum Tipo {
	INEM, Bombeiros, GNR, PSP,PJ;
}