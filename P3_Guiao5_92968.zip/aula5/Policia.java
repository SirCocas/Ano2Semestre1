package aula5;
public interface Policia {
	public Tipo getTipo();
	public String getID();
	public String toString();

}