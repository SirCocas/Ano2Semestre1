package aula5;
import java.io.*;

public class writeFile {
	
	public static void writeCSV(String filename, Contacto[] arr) throws IOException {
		File out = new File(filename);
		PrintWriter write = new PrintWriter(out);
		write.println("CSV");
		for(int i=0; i<arr.length; i++) {
			write.println(arr[i].nome()+"\t"+ arr[i].phone()+"\t"+ arr[i].nascimento().dia()+"/"+arr[i].nascimento().mes()+"/"+arr[i].nascimento().ano());
		}
		write.close();
		
	}
	
	public static void writeVCard(String filename, Contacto[] arr) throws IOException{
		File out = new File(filename);
		PrintWriter write = new PrintWriter(out);
		write.println("vCard");
		for(int i=0; i<arr.length; i++) {
			write.println("#"+arr[i].nome()+"#"+ arr[i].phone()+"#"+ arr[i].nascimento().dia()+"/"+arr[i].nascimento().mes()+"/"+arr[i].nascimento().ano());
		}
		write.close();
		
	}
	
	public static void writeNOKIA(String filename, Contacto[] arr) throws IOException{
		File out = new File(filename);
		PrintWriter write = new PrintWriter(out);
		write.println("Nokia");
		for(int i=0; i<arr.length; i++) {
			write.println(arr[i].nome());
			write.println(arr[i].phone());
			write.println(arr[i].nascimento().dia()+"/"+arr[i].nascimento().mes()+"/"+arr[i].nascimento().ano());
			write.println("");
		}
		write.close();
		
	}

}
