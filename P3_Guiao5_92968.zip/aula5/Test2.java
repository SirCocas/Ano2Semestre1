package aula5;

//os valores aqui inseridos são o que me veio à cabeça no momento, por isso, é possível que haja valores absurdos

public class Test2 {

	public static void main(String[] args) {
		Veiculo[] carros = new Veiculo[6];
		carros[0]= new CarroPolicia(2000, "AAA-BBB-AAA", Cor.WHITE, 192,150.5, Tipo.INEM, 50, 30.5, Combustivel.GASOLINA);
		carros[1]= new Bicicleta(1997, "AAA-BBB-AAA", Cor.PINK, 13);
		carros[2]= new BicicletaPolicia(1577, "OLDR-EALL-YOLD", Cor.BROWN, 3, Tipo.PSP);
		carros[3]= new MotoPolicia(2019, "COPS-COPS-COPS", Cor.GREEN, 730, 200.6, Tipo.GNR, 300, 15.5, Combustivel.GASOLINA); 
		carros[4]= new Moto(1923, "AAA-GGG-WWW", Cor.RED, 129, 54.4, 123, 33.2, Combustivel.GASOLEO);
		carros[5]= new CarroPolicia(2000, "AAA-BBB-AAA", Cor.WHITE, 192,150.5, Tipo.INEM, 50, 30.5, Combustivel.GASOLINA);
		System.out.println("Lista original:");
		for(int i=0; i<carros.length; i++) {
			System.out.println(carros[i]);
		}
		
		System.out.println("Lista ordenada:");
		UtilCompare.sortArray(carros);
		for(int i=0; i<carros.length; i++) {
			System.out.println(carros[i]);
		}
	}
}
