package aula5;

public enum Cor {
	RED, GREEN, BLUE, BLACK, GRAY, WHITE, SILVER, BROWN, PINK;
}  