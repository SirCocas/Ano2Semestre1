package aula5;

import aula3.Data;

public class Contacto {
	private String nome="";
	private String phone="";
	private Data nascimento;
	
	public Contacto(String nome, String phone,Data nascimento) {
		this.nome=nome;
		this.phone=phone;
		this.nascimento=nascimento;
	}
	
	public String nome() {
		return nome;
	}
	
	public String phone() {
		return phone;
	}
	
	public Data nascimento() {
		return nascimento;
	}
	
	public Contacto(String nome, String phone, int dia, int mes, int ano) {
		Data placeholder = new Data(dia, mes, ano);
		this.nome=nome;
		this.phone=phone;
		this.nascimento=placeholder;
	}
	public Contacto(String nome, String phone, String data) {
		String[] novaData = data.split("/");
		int dia= Integer.parseInt(novaData[0]);
		int mes= Integer.parseInt(novaData[1]);
		int ano = Integer.parseInt(novaData[2]);
		Data placeholder = new Data(dia, mes, ano);
		this.nome=nome;
		this.phone=phone;
		nascimento=placeholder;
	}
	
	@Override public String toString() {
		return "Nome: "+nome+" Telemovel: "+phone+" Data: "+ nascimento.toString();
	}
}
