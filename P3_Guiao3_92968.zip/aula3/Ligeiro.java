package aula3;

public class Ligeiro extends Motociclo {

	public Ligeiro(Motociclo thingThatMoves) {
		super(thingThatMoves.driver(), thingThatMoves.cilindrada(), thingThatMoves.potencia());
	}

	public String toString() {
		return "Tipo de carro: Ligeiro ||" + super.toString();
	}

}
