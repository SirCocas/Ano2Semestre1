package aula3;

public class Test3 {

	public static void main(String[] args) {
		int potencia = 120; // 120CC é potência? e cilindrada tamanho em cm^3?
		int cilindrada = 130; //
		int weightMerc = 100;
		int lotacao = 50;
		Condutor driver = new Condutor("Manuel", 1234, new Data(1, 4, 1990), 'A');
		Motociclo thingThatMoves = new Motociclo(driver, cilindrada, potencia);
		Ligeiro light = new Ligeiro(thingThatMoves);
		System.out.println(light);
		PesadoMerc transport = new PesadoMerc(thingThatMoves, weightMerc);
		System.out.println(transport);
		PesadoP bus = new PesadoP(thingThatMoves, lotacao);
		System.out.println(bus);
		Condutor driver2 = new Condutor("Maria", 1234, new Data(1, 4, 2019), 'D');
		bus.setCondutor(driver2);
		System.out.println("--TESTE DE NOVO CONDUTOR E IDADE MUDADA--");
		System.out.println(bus);
	}

}
