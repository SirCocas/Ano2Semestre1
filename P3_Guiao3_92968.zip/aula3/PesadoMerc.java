package aula3;

public class PesadoMerc extends Motociclo {
	private int weightCargo = 0;

	public PesadoMerc(Motociclo thingThatMoves, int weightMerc) {
		super(thingThatMoves.driver(), thingThatMoves.cilindrada(), thingThatMoves.potencia());
		weightCargo = weightMerc;
	}

	@Override
	public String toString() {
		return "Tipo de carro: Pesado de mercadoria || Peso da merdadoria: " + weightCargo + "kg ||" + super.toString();
	}

}
