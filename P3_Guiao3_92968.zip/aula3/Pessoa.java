package aula3;

public class Pessoa {
	private String nome;
	private Data DataNasc;
	private int BI;

	public Pessoa(String nome, int bi, Data data) {
		this.nome = nome;
		BI = bi;
		DataNasc = data;
	}

	public String nome() {
		return nome;
	}

	public Data DataNasc() {
		return DataNasc;
	}

	public int BI() {
		return BI;
	}

	@Override
	public String toString() {
		return ("Nome: " + nome + "|| Data de nascimento: " + DataNasc.toString() + "|| BI: " + BI);
	}

	public void setAno(int ano) {
		DataNasc = new Data(DataNasc.dia(), DataNasc.mes(), ano);
	}
}
