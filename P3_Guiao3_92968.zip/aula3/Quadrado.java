package aula3;

public class Quadrado extends Figura {
	private int side;

	public Quadrado(int i) {
		super();
		if (i > 0)
			side = i;
	}

	public Quadrado(int i, int j, int k) {
		super(i, j);
		if (k > 0)
			side = k;
	}

	public Quadrado(Quadrado q2) {
		super(q2.centro);
		this.side = q2.side;
	}

	public double area() {
		return side * side;
	}

	public double perimetro() {
		return side * 4;
	}

	public boolean equals(Object rhs) {
		// Não é necessário testar a classe. Feito em base
		return super.equals(rhs) && side == ((Quadrado) rhs).side;
	}

	@Override
	public String toString() {
		return (super.toString() + "|| Lado: " + side);
	}

}
