package aula3;

public class Condutor extends Pessoa {
	private char TipoDeCarta = 'A';

	public Condutor(String nome, int BI, Data data, char c) {
		super(nome, BI, data);
		if (data.ano() > 2001) // se tiverem menos de 18
			super.setAno(2001);
		if (c == 'A' || c == 'B' || c == 'C' || c == 'D')
			this.TipoDeCarta = c;
	}

	@Override
	public String toString() {
		return (super.toString() + "Tipo de Carta: " + TipoDeCarta);
	}

}
