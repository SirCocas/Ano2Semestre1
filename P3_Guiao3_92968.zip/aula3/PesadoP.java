package aula3;

public class PesadoP extends Motociclo {
	private int maxppl = 0;

	public PesadoP(Motociclo thingThatMoves, int maxppl) {
		super(thingThatMoves.driver(), thingThatMoves.cilindrada(), thingThatMoves.potencia());
		this.maxppl = maxppl;
	}

	@Override
	public String toString() {
		return "Tipo de carro: Pesado de transporte de pessoas || Máximo de passageiros: " + maxppl + "kg ||"
				+ super.toString();
	}

}
