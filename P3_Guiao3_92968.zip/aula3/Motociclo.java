package aula3;

public class Motociclo {
	private Condutor driver;
	private int cilindrada = 0;
	private int potencia = 0;

	public Condutor driver() {
		return driver;
	}

	public int cilindrada() {
		return cilindrada;
	}

	public int potencia() {
		return potencia;
	}

	public Motociclo(Condutor driver, int cilindrada, int potencia) {
		this.driver = driver;
		this.cilindrada = cilindrada;
		this.potencia = potencia;
	}

	@Override
	public String toString() {
		return ("Condutor: " + driver.toString() + "|| Cilindrada: " + cilindrada + "cm^3 || Potencia: " + potencia
				+ "CC");
	}

	public void setCondutor(Condutor driver) {
		this.driver = driver;
	}

}
